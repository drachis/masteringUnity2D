(function() {
    "use strict";

    // *** PACKAGES ***
    var fs                   = require("fs");
    var path                 = require("path");
    var pluginPackage        = require("./package.json");

    // *** CONSTANTS ***
    var MENU_ID              = pluginPackage.name;        // our plugin's menu id
    var MENU_STRING          = "Ps2D Map";                // our plugin's menu text
    var PLUGIN_VERSION       = pluginPackage.version;     // our plugin version
    var PLUGIN_NAME          = pluginPackage.name;        // plugin name
    var MAP_EXTENSION        = ".ps2dmap.json";           // map's extension

    // *** STATE VARIABLES ***
    var _generator           = null;  // the generator framework
    var _currentDocumentId   = null;  // the document's id
    var _currentDocumentFile = null;  // the document's filename

    // *** PLUGIN FUNCTIONALITY

    // kick it off!
    function run() {

        // request the document from photoshop
        _generator.getDocumentInfo(_currentDocumentId)

            .then(function(document) {
                _currentDocumentFile = document.file;
                var layoutDocument   = createLayoutDocument(document);
                saveMapFile(layoutDocument);
                popup("The Ps2D map file has been created.  Hurray!");
            })

            .done();

    }

    // Get the full filename for the layout file we create.
    // It will be written in the same directory as the PSD file.
    function layoutFilename() {
        var myExtension = path.extname(_currentDocumentFile);
        var myBasename  = path.basename(_currentDocumentFile, myExtension);
        var myPath      = path.dirname(_currentDocumentFile);

        return myPath + path.sep + myBasename + MAP_EXTENSION;
    }

    // save the layout to the file system
    function saveMapFile(layoutDocument) {

        // get the filename
        var filename = layoutFilename();

        // serialize our layoutDocument to a string
        var contents = JSON.stringify(layoutDocument);

        try
        {
            // a synchronous node.js call?  finally, sanity!!!  just kidding.  mostly.
            fs.writeFileSync(filename, contents);
        } catch (err)
        {
            // TODO: It'd be nice to show people a message instead of just logging
            log("unable to save map file to " + filename);
        }
    }

    // convert the photoshop document to our own layout document
    function createLayoutDocument(document) {
        // create our own document
        var layoutDocument = {};

        layoutDocument.pluginVersion = PLUGIN_VERSION;
        layoutDocument.bounds        = document.bounds;
        layoutDocument.mask          = document.mask;
        layoutDocument.sprites       = convertLayersToSprites(document.layers);

        return layoutDocument;
    }

    // convert a list of layers into a list of sprites
    function convertLayersToSprites(layers) {
        // sanity
        if (layers === null || layers === undefined || layers.length === 0)
            return null;

        // sprites go here
        var sprites = [];

        // go through each layer
        for (var i = 0, z = layers.length; i < z; i++)
        {
            var layer = layers[i];

            // convert it
            var sprite = convertLayerToSprite(layer);

            // add it to the list if it's legit
            if (sprite !== null) {
                sprites.push(sprite);
            }
        }

        return sprites;

    }

    // convert a ps layer to a sprite
    function convertLayerToSprite(layer) {

        // safety
        if (layer === null || layer === undefined) return null;

        // grab what we need for our map
        var sprite = {};
        sprite.id      = layer.id;
        sprite.name    = layer.name;
        sprite.bounds  = layer.bounds;
        sprite.mask    = layer.mask;
        sprite.visible = layer.visible;
        sprite.sprites = convertLayersToSprites(layer.layers);

        return sprite;
    }

    // *** EVENT HANDLERS ***

    // fires when we've installed successfully
    function handleMenuItemInstallSuccess() {}

    // fires when PS can't install our menu item
    function handleMenuItemInstallFailed() {
        log("Unable to create Ps2D menu item.");
    }

    // the user has clicked our menu item
    function handleGeneratorMenuClicked(e) {
        // which menu item caused this event?
        var menu = e.generatorMenuChanged;

        // if it wasn't us, jet.
        if (!menu || menu.name !== MENU_ID) return;

        // ok, it's go time!
        run();
    }

    // the photoshop document has changed
    function handleCurrentDocumentChanged(id) {
        _currentDocumentId = id;
    }

    // *** UTILITIES ***

    // write a log message
    function log(s) {
        console.log("[" + PLUGIN_NAME + "] " + s);
    }

    // show a popup message
    function popup(msg) {
        var js = "alert('" + msg + "');"
        sendJavascript(js);
    }

    // run some javascript
    function sendJavascript(str){
        _generator.evaluateJSXString(str).then(
            function(result){
                console.log(result);
            },
            function(err){
                console.log(err);
            });
    }

    // *** INITIALIZATION ***

    // main entry point for the plugin
    function init(generator) {

        // remember this generator in our scope
        _generator = generator;

        // install the menu item
        _generator
            .addMenuItem(MENU_ID, MENU_STRING, true, false)
            .then(handleMenuItemInstallSuccess, handleMenuItemInstallFailed);

        // subscribe to PS events
        _generator.onPhotoshopEvent("generatorMenuChanged", handleGeneratorMenuClicked);
    }

    // make our entry point available
    exports.init = init;

}());
